<?php

class Controller_Product_Media{

    public function helloAction()
    {
        # code...
        echo "hiiiii";
    }
}
?>
