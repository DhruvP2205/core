<?php
Ccc::loadClass('Model_Core_View');
class Block_Core_Template extends Model_Core_View   
{ 
   
}




